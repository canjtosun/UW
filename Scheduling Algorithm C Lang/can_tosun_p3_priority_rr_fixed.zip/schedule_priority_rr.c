//Can Tosun
//CSS 430 P3

#include <stdio.h>
#include <stdlib.h>

#include "task.h"
#include "cpu.h"
#include "list.h"
#include "schedulers.h"

struct node* head = NULL;
struct node* extraList = NULL;


void pickNextTask()
{
    //if the list is empty, return
    if(!extraList)
        return;

    //create a new node
    struct node *newNode;
    newNode = extraList;

    //as long as the burst is bigger or equal to 10
    //and the next node is not null
    //constantly decrement
    while(newNode->task->burst >= QUANTUM  && newNode->next != NULL)
    {
        run(newNode->task, QUANTUM); //print the task out
        newNode->task->burst -= QUANTUM; //decrement

        //check if next node has the same priority
        while(newNode->task->priority == newNode->next->task->priority)
        {
            newNode = newNode->next; //move to the next node
            run(newNode->task, QUANTUM);  //print the task out
            newNode->task->burst -= QUANTUM;  //decrement
        }

        //if you hit zero
        if(newNode->task->burst == 0)
        {
            delete(&extraList, newNode->task);// delete the node
            newNode = newNode->next; // adn move to the next
        }

        //if less than zero
        if(newNode->task->burst < QUANTUM) 
        {
            run(newNode->task, newNode->task->burst); //first print out the leftover
            delete(&extraList, newNode->task); //delete the node
            newNode = newNode->next; //and move to the next
        }

        //if none of them, just move to the next
        else
            newNode = extraList;

    }

    //if the leftover less than quantum time but outside of while loop
    //print out delete and move to the next
    run(newNode->task, newNode->task->burst);
    delete(&extraList, newNode->task);
    newNode = newNode->next;  
}

void extraListMethod()
{
    
    while(head != NULL)
    {
        //create 2 new node and assign to head
        struct node* choose; 
        struct node* current;
        current = head;
        choose = head;

        //go thru the list
        while(current != NULL)
        {
            //choose higher priority
            if(current->task->priority < choose->task->priority)
                choose = current;

            current = current->next;
        }

        //insert to the other list and delete from list
        insert(&extraList, choose->task);
        delete(&head, choose->task);

    }

}


void schedule()
{
    extraListMethod(); //call extralist priority ordered

    while(extraList != NULL) //go until the end of the list
    {
        pickNextTask();  // choose next task  
    }

    printf("Done\n");
}

void add(char* name, int priority, int burst)
{
    Task *newTask = malloc(sizeof(Task)); //create new task

    //initilization
    newTask->name = name;
    newTask->priority = priority;
    newTask->burst = burst;

    //insertion
    insert(&head, newTask);     
}